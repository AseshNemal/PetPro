package com.example.petpro

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import com.google.android.material.bottomnavigation.BottomNavigationView

class VaccinationsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vaccinations)

        // Find the back button
        val backButton: ImageView = findViewById(R.id.back_button)

        // Set a click listener for the back button
        backButton.setOnClickListener {
            onBackPressed() // Go back to the previous activity
        }

        findViewById<View>(R.id.smart_summary).setOnClickListener{
            val intent = Intent(this,PetLogsActivity::class.java)
            startActivity(intent)
        }
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_pet_logs -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_records -> {
                    val intent = Intent(this, VaccinationsActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_stats -> {
                    val intent = Intent(this, PetHealthActivity::class.java)
                    startActivity(intent)
                    true
                }

                R.id.nav_account -> {
                    val intent = Intent(this, UserAccountActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }
}