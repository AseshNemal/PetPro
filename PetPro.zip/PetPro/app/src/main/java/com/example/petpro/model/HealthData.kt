import java.text.SimpleDateFormat
import java.util.*

data class HealthData(
    var temperature: Float? = null,
    var heartRate: Int? = null,
    var steps: Int? = null,
    var airQuality: Int? = null,
    var humidity: Int? = null,
    var timestamp: Long = System.currentTimeMillis()
) {
    fun hasTemperature() = temperature != null
    fun hasHeartRate() = heartRate != null
    fun hasSteps() = steps != null
    fun hasAirQuality() = airQuality != null
    fun hasHumidity() = humidity != null
    fun isEmpty() = !hasTemperature() && !hasHeartRate() && !hasSteps() &&
            !hasAirQuality() && !hasHumidity()

    fun getFormattedTime(): String {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
    }

    fun getFormattedDate(): String {
        return SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(timestamp))
    }
}