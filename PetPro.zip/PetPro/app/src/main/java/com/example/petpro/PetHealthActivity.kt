package com.example.petpro

import HealthData
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.formatter.ValueFormatter
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random


class PetHealthActivity : AppCompatActivity() {

    // Views
    private lateinit var connectionStatusIcon: ImageView
    private lateinit var connectionStatusText: TextView
    private lateinit var temperatureSummary: TextView
    private lateinit var heartRateSummary: TextView
    private lateinit var stepsSummary: TextView
    private lateinit var airQualitySummary: TextView
    private lateinit var humiditySummary: TextView
    private lateinit var lastUpdatedText: TextView
    private lateinit var healthDataTable: TableLayout

    // Charts
    private lateinit var temperatureChart: LineChart
    private lateinit var heartRateChart: LineChart
    private lateinit var stepsChart: LineChart
    private lateinit var airQualityChart: LineChart
    private lateinit var humidityChart: LineChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_health)

        initViews()
        loadDataAndSetupUI()
    }

    private fun initViews() {
        // Summary views
        connectionStatusIcon = findViewById(R.id.connectionStatusIcon)
        connectionStatusText = findViewById(R.id.connectionStatusText)
        temperatureSummary = findViewById(R.id.temperatureSummary)
        heartRateSummary = findViewById(R.id.heartRateSummary)
        stepsSummary = findViewById(R.id.stepsSummary)
        airQualitySummary = findViewById(R.id.airQualitySummary)
        humiditySummary = findViewById(R.id.humiditySummary)
        lastUpdatedText = findViewById(R.id.lastUpdatedText)
        healthDataTable = findViewById(R.id.healthDataTable)

        // Charts
        temperatureChart = findViewById(R.id.temperatureChart)
        heartRateChart = findViewById(R.id.heartRateChart)
        stepsChart = findViewById(R.id.stepsChart)
        airQualityChart = findViewById(R.id.airQualityChart)
        humidityChart = findViewById(R.id.humidityChart)
    }

    private fun loadDataAndSetupUI() {
        val historicalData = getHistoricalData()

        if (historicalData.isEmpty()) {
            showEmptyState()
            return
        }

        // Process last data point for summary
        val lastData = historicalData.last()
        updateUIWithData(lastData)

        // Setup charts and table
        setupAllCharts(historicalData)
        setupHealthDataTable(historicalData)
    }

    private fun setupHealthDataTable(dataList: List<HealthData>) {
        healthDataTable.removeAllViews()

        // Create header row
        val headerRow = TableRow(this).apply {
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Add headers
        listOf("Time", "Temp (°C)", "HR (BPM)", "Steps", "Air Q", "Humidity (%)").forEach { header ->
            headerRow.addView(TextView(this).apply {
                text = header
                textSize = 12f
                setTextColor(Color.BLACK)
                setTypeface(null, Typeface.BOLD)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })
        }

        healthDataTable.addView(headerRow)

        // Add divider
        val divider = View(this).apply {
            layoutParams = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                1
            )
            setBackgroundColor(Color.LTGRAY)
        }
        healthDataTable.addView(divider)

        // Add data rows (show only last 5 entries)
        dataList.takeLast(5).forEach { data ->
            val row = TableRow(this).apply {
                layoutParams = TableLayout.LayoutParams(
                    TableLayout.LayoutParams.WRAP_CONTENT,
                    TableLayout.LayoutParams.WRAP_CONTENT
                )
            }

            // Time column
            row.addView(TextView(this).apply {
                text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(data.timestamp))
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            // Temperature column
            row.addView(TextView(this).apply {
                text = data.temperature?.let { "%.1f".format(it) } ?: "--"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            // Heart Rate column
            row.addView(TextView(this).apply {
                text = data.heartRate?.toString() ?: "--"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            // Steps column
            row.addView(TextView(this).apply {
                text = data.steps?.toString() ?: "--"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            // Air Quality column
            row.addView(TextView(this).apply {
                text = data.airQuality?.toString() ?: "--"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            // Humidity column
            row.addView(TextView(this).apply {
                text = data.humidity?.toString() ?: "--"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                setPadding(8, 8, 8, 8)
                gravity = Gravity.CENTER
            })

            healthDataTable.addView(row)
        }
    }

    private fun showEmptyState() {
        connectionStatusIcon.setImageResource(R.drawable.ic_disconnected)
        connectionStatusText.text = "No data"
        connectionStatusText.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))

        setSummaryText(temperatureSummary, "--")
        setSummaryText(heartRateSummary, "--")
        setSummaryText(stepsSummary, "--")
        setSummaryText(airQualitySummary, "--")
        setSummaryText(humiditySummary, "--")

        lastUpdatedText.text = "Last updated: Never"
    }

    private fun updateUIWithData(data: HealthData) {
        updateConnectionStatus(isDataFresh(data.timestamp))

        temperatureSummary.text = data.temperature?.let { "%.1f°C".format(it) } ?: "--"
        heartRateSummary.text = data.heartRate?.let { "$it BPM" } ?: "--"
        stepsSummary.text = data.steps?.toString() ?: "--"
        airQualitySummary.text = data.airQuality?.let { getAirQualityString(it) } ?: "--"
        humiditySummary.text = data.humidity?.let { "$it%" } ?: "--"

        setSummaryText(temperatureSummary, temperatureSummary.text.toString())
        setSummaryText(heartRateSummary, heartRateSummary.text.toString())
        setSummaryText(stepsSummary, stepsSummary.text.toString())
        setSummaryText(airQualitySummary, airQualitySummary.text.toString())
        setSummaryText(humiditySummary, humiditySummary.text.toString())

        updateLastUpdatedTime(data.timestamp)
    }

    private fun updateConnectionStatus(isConnected: Boolean) {
        if (isConnected) {
            connectionStatusIcon.setImageResource(R.drawable.ic_connected)
            connectionStatusText.text = "Connected"
            connectionStatusText.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
        } else {
            connectionStatusIcon.setImageResource(R.drawable.ic_disconnected)
            connectionStatusText.text = "Disconnected"
            connectionStatusText.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        }
    }

    private fun isDataFresh(timestamp: Long): Boolean {
        return (System.currentTimeMillis() - timestamp) < (2 * 60 * 1000)
    }

    private fun updateLastUpdatedTime(timestamp: Long) {
        val sdf = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        lastUpdatedText.text = "Last updated: ${sdf.format(Date(timestamp))}"
    }

    private fun setSummaryText(textView: TextView, text: String) {
        textView.text = text
        textView.setTextColor(
            ContextCompat.getColor(
                this,
                if (text == "--") android.R.color.darker_gray else android.R.color.black
            )
        )
    }

    private fun getAirQualityString(value: Int): String {
        return when {
            value < 50 -> "Good"
            value < 100 -> "Moderate"
            value < 150 -> "Unhealthy (Sensitive)"
            value < 200 -> "Unhealthy"
            value < 300 -> "Very Unhealthy"
            else -> "Hazardous"
        }
    }

    private fun setupAllCharts(dataList: List<HealthData>) {
        val tempEntries = mutableListOf<Entry>()
        val hrEntries = mutableListOf<Entry>()
        val stepsEntries = mutableListOf<Entry>()
        val aqEntries = mutableListOf<Entry>()
        val humidityEntries = mutableListOf<Entry>()

        dataList.forEachIndexed { index, data ->
            if (data.hasTemperature()) tempEntries.add(Entry(index.toFloat(), data.temperature!!))
            if (data.hasHeartRate()) hrEntries.add(Entry(index.toFloat(), data.heartRate!!.toFloat()))
            if (data.hasSteps()) stepsEntries.add(Entry(index.toFloat(), data.steps!!.toFloat()))
            if (data.hasAirQuality()) aqEntries.add(Entry(index.toFloat(), data.airQuality!!.toFloat()))
            if (data.hasHumidity()) humidityEntries.add(Entry(index.toFloat(), data.humidity!!.toFloat()))
        }

        setupChart(temperatureChart, tempEntries, "Temperature (°C)", Color.parseColor("#FF5722"), TimeValueFormatter(dataList))
        setupChart(heartRateChart, hrEntries, "Heart Rate (BPM)", Color.parseColor("#F44336"), TimeValueFormatter(dataList))
        setupChart(stepsChart, stepsEntries, "Steps Count", Color.parseColor("#4CAF50"), TimeValueFormatter(dataList))
        setupChart(airQualityChart, aqEntries, "Air Quality", Color.parseColor("#2196F3"), TimeValueFormatter(dataList))
        setupChart(humidityChart, humidityEntries, "Humidity (%)", Color.parseColor("#9C27B0"), TimeValueFormatter(dataList))
    }

    private fun setupChart(chart: LineChart, entries: List<Entry>, label: String, color: Int, formatter: ValueFormatter) {
        ChartUtils.setupChart(chart, label, color, entries, formatter)
    }

    private inner class TimeValueFormatter(private val dataList: List<HealthData>) : ValueFormatter() {
        private val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())

        override fun getFormattedValue(value: Float): String {
            val index = value.toInt()
            return if (index in dataList.indices) {
                sdf.format(Date(dataList[index].timestamp))
            } else ""
        }
    }

    private fun getHistoricalData(): List<HealthData> {
        val dataList = mutableListOf<HealthData>()
        val now = System.currentTimeMillis()
        val random = Random(System.currentTimeMillis())

        repeat(24) { i ->
            HealthData().apply {
                timestamp = now - (23 - i) * 3600000

                if (random.nextFloat() > 0.2) temperature = 38.0f + random.nextFloat() * 2
                if (random.nextFloat() > 0.2) heartRate = 80 + random.nextInt(60)
                if (random.nextFloat() > 0.3) steps = random.nextInt(500)
                if (random.nextFloat() > 0.4) airQuality = random.nextInt(300)
                if (random.nextFloat() > 0.2) humidity = 30 + random.nextInt(60)

                dataList.add(this)
            }
        }

        return dataList
    }
}